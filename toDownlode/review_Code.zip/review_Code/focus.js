setFocuseTxtMission();
function setFocuseTxtMission() {
  const txtMission = document.getElementById("txtMission");
  txtMission.focus();
}
