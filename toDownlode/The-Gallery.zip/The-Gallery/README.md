# Gallery

A gallery app organizes and displays images offering sharing features. It helps users manage their visual content efficiently on mobile or computer devices.

to watch The Gallery [here](https://chananelazenkot.github.io/The-Gallery/).

## Features

- Sharing: Share media files seamlessly across different platforms.
- Optimized for mobile for the most enjoyable viewing.
- A beautifully designed application with a transition between images.

## How is work ?

1. Open the website application.
2. The images at first will change by themselves with animation.
3. You have the option of buttons that are only visible when you click on the image, so you can browse.
4. enjoy From My Photos 📸.